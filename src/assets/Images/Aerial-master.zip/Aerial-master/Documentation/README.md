#  Welcome to Aerial's documentation

This documentation is still a work in progress, if you have any further question don't hesitate to post an issue. 


- [Troubleshooting information](Troubleshooting.md)



- [Aerial's Change log](ChangeLog.md)

- [Information on compiling Aerial and contributing code](Contribute.md)


- [Offline mode and no network access.](OfflineMode.md)
- [HEVC, HDR and hardware decoding](HardwareDecoding.md) 
- [How to add your own videos to Aerial](CustomVideos.md)
- [Auto-updates](AutoUpdates.md)
